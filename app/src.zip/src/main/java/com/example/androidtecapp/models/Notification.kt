package com.example.androidtecapp.models

data class Notification(
    val NotificationType: String = "",
    val Message: String = "",

)