package com.example.androidtecapp.network.responses

import com.example.androidtecapp.models.User

data class UserResponse(
    val user: User
)
